module.exports=[30689,(a,b,c)=>{}];

//# sourceMappingURL=14xo__next-internal_server_app_%28auth%29_forgot-password_page_actions_05we090.js.map