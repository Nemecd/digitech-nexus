globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/-ql8pK_-NdEVWcBX_GCLj/_buildManifest.js",
    "static/-ql8pK_-NdEVWcBX_GCLj/_ssgManifest.js",
    "static/-ql8pK_-NdEVWcBX_GCLj/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/2xezw76qfhmml.js",
    "static/chunks/2mfe3hrji_h-z.js",
    "static/chunks/0-xm3jab8tnu0.js",
    "static/chunks/1pvz9tje134hi.js",
    "static/chunks/25y_d47z4zvdf.js",
    "static/chunks/turbopack-0qv7ff8j5jdhx.js"
  ]
};
