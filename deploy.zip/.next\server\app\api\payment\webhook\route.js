var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/payment/webhook/route.js")
R.c("server/chunks/[root-of-the-server]__0gl8vb7._.js")
R.c("server/chunks/04ni_@supabase_supabase-js_dist_index_mjs_04mz8lq._.js")
R.c("server/chunks/[root-of-the-server]__1jr76q4._.js")
R.c("server/chunks/14xo__next-internal_server_app_api_payment_webhook_route_actions_001c3e6.js")
R.m(10950)
module.exports=R.m(10950).exports
