1:"$Sreact.fragment"
2:I[74876,["/_next/static/chunks/3bgr6y9u4sws3.js","/_next/static/chunks/1q-d6daimrahe.js"],"default"]
3:I[42903,["/_next/static/chunks/3bgr6y9u4sws3.js","/_next/static/chunks/1q-d6daimrahe.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"-ql8pK_-NdEVWcBX_GCLj"}
