var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[externals]_next_dist_1ce_grm._.js")
R.c("server/chunks/[root-of-the-server]__1jr76q4._.js")
R.c("server/chunks/04ni_next_dist_esm_build_templates_app-route_08per3c.js")
R.c("server/chunks/digitech-nexus__next-internal_server_app_favicon_ico_route_actions_0erqyvm.js")
R.m(65635)
module.exports=R.m(65635).exports
