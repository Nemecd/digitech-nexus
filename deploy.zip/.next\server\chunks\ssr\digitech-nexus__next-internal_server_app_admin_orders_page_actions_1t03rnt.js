module.exports=[75337,(a,b,c)=>{}];

//# sourceMappingURL=digitech-nexus__next-internal_server_app_admin_orders_page_actions_1t03rnt.js.map