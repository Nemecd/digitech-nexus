var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/ref/track/route.js")
R.c("server/chunks/[root-of-the-server]__1i-vjdh._.js")
R.c("server/chunks/04ni_@supabase_supabase-js_dist_index_mjs_04mz8lq._.js")
R.c("server/chunks/[root-of-the-server]__1jr76q4._.js")
R.c("server/chunks/digitech-nexus__next-internal_server_app_api_ref_track_route_actions_216-fg6.js")
R.m(43547)
module.exports=R.m(43547).exports
