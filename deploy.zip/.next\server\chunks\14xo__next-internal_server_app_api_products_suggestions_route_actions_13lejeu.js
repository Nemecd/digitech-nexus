module.exports=[64858,(e,o,d)=>{}];

//# sourceMappingURL=14xo__next-internal_server_app_api_products_suggestions_route_actions_13lejeu.js.map