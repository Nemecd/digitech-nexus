module.exports=[25824,(a,b,c)=>{}];

//# sourceMappingURL=digitech-nexus__next-internal_server_app_shop_page_actions_0cnxrj-.js.map