module.exports=[28391,(a,b,c)=>{}];

//# sourceMappingURL=digitech-nexus__next-internal_server_app_student-placement_page_actions_1uq18w9.js.map