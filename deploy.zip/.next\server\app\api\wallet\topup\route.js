var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/wallet/topup/route.js")
R.c("server/chunks/[root-of-the-server]__1x16h5v._.js")
R.c("server/chunks/digitech-nexus_171e1t8._.js")
R.c("server/chunks/04ni_@supabase_supabase-js_dist_index_mjs_04mz8lq._.js")
R.c("server/chunks/[root-of-the-server]__1jr76q4._.js")
R.c("server/chunks/digitech-nexus__next-internal_server_app_api_wallet_topup_route_actions_0-936q1.js")
R.m(87881)
module.exports=R.m(87881).exports
