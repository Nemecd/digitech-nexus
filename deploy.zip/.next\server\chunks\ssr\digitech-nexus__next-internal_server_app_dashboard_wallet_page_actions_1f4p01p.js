module.exports=[46794,(a,b,c)=>{}];

//# sourceMappingURL=digitech-nexus__next-internal_server_app_dashboard_wallet_page_actions_1f4p01p.js.map