module.exports=[85746,(a,b,c)=>{}];

//# sourceMappingURL=digitech-nexus__next-internal_server_app_page_actions_1pdwjea.js.map