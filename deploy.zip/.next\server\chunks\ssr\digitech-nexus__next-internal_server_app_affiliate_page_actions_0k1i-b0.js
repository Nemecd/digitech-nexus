module.exports=[47972,(a,b,c)=>{}];

//# sourceMappingURL=digitech-nexus__next-internal_server_app_affiliate_page_actions_0k1i-b0.js.map