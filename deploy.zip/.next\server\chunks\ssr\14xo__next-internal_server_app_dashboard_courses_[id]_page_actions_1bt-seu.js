module.exports=[51168,(a,b,c)=>{}];

//# sourceMappingURL=14xo__next-internal_server_app_dashboard_courses_%5Bid%5D_page_actions_1bt-seu.js.map