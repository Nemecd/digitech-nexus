module.exports=[78323,(a,b,c)=>{}];

//# sourceMappingURL=digitech-nexus__next-internal_server_app__global-error_page_actions_0zx5vj6.js.map