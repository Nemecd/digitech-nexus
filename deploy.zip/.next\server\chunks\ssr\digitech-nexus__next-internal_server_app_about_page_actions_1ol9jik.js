module.exports=[65935,(a,b,c)=>{}];

//# sourceMappingURL=digitech-nexus__next-internal_server_app_about_page_actions_1ol9jik.js.map