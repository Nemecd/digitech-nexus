module.exports=[13814,(e,o,d)=>{}];

//# sourceMappingURL=digitech-nexus__next-internal_server_app_favicon_ico_route_actions_0erqyvm.js.map