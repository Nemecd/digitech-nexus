module.exports=[70878,(a,b,c)=>{}];

//# sourceMappingURL=digitech-nexus__next-internal_server_app_%28auth%29_register_page_actions_1lb7s1g.js.map