module.exports=[89889,(a,b,c)=>{}];

//# sourceMappingURL=digitech-nexus__next-internal_server_app_ebooks_page_actions_0ac2e2x.js.map