module.exports=[91646,(a,b,c)=>{}];

//# sourceMappingURL=digitech-nexus__next-internal_server_app_checkout_success_page_actions_12i0d3x.js.map