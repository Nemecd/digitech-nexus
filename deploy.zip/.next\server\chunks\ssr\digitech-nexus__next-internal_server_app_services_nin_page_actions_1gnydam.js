module.exports=[5435,(a,b,c)=>{}];

//# sourceMappingURL=digitech-nexus__next-internal_server_app_services_nin_page_actions_1gnydam.js.map