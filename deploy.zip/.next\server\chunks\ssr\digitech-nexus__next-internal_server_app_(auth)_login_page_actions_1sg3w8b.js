module.exports=[18538,(a,b,c)=>{}];

//# sourceMappingURL=digitech-nexus__next-internal_server_app_%28auth%29_login_page_actions_1sg3w8b.js.map