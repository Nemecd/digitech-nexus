module.exports=[8220,(e,o,d)=>{}];

//# sourceMappingURL=digitech-nexus__next-internal_server_app_api_ref_track_route_actions_216-fg6.js.map