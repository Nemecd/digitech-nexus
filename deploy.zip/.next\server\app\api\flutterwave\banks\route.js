var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/flutterwave/banks/route.js")
R.c("server/chunks/[root-of-the-server]__03w0d5f._.js")
R.c("server/chunks/[root-of-the-server]__1jr76q4._.js")
R.c("server/chunks/14xo__next-internal_server_app_api_flutterwave_banks_route_actions_12t3lg3.js")
R.m(15351)
module.exports=R.m(15351).exports
