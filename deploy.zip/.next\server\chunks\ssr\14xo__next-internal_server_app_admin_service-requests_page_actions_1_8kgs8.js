module.exports=[72795,(a,b,c)=>{}];

//# sourceMappingURL=14xo__next-internal_server_app_admin_service-requests_page_actions_1_8kgs8.js.map