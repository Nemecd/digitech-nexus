globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/Vc85XfKqI6lI9FCcW022V/_buildManifest.js",
    "static/Vc85XfKqI6lI9FCcW022V/_ssgManifest.js",
    "static/Vc85XfKqI6lI9FCcW022V/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3ngtgxy78ffo9.js",
    "static/chunks/1sgsj5ncjvasa.js",
    "static/chunks/3rrrfq2x6i-_b.js",
    "static/chunks/1pvz9tje134hi.js",
    "static/chunks/25y_d47z4zvdf.js",
    "static/chunks/0-xm3jab8tnu0.js",
    "static/chunks/turbopack-0khr9hnyxopqb.js"
  ]
};
