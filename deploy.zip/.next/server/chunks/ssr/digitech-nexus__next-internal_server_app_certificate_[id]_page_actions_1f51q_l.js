module.exports=[38293,(a,b,c)=>{}];

//# sourceMappingURL=digitech-nexus__next-internal_server_app_certificate_%5Bid%5D_page_actions_1f51q_l.js.map