1:"$Sreact.fragment"
2:"$Sreact.suspense"
3:I[7302,["/_next/static/chunks/0f2rswepr36h9.js","/_next/static/chunks/1q-d6daimrahe.js","/_next/static/chunks/2-1_xj7azti80.js","/_next/static/chunks/21rzh-zxtimdt.js"],"default"]
4:I[31780,["/_next/static/chunks/0f2rswepr36h9.js","/_next/static/chunks/1q-d6daimrahe.js"],"OutletBoundary"]
0:{"rsc":["$","$1","c",{"children":[["$","$2",null,{"fallback":["$","div",null,{"className":"min-h-[60vh]"}],"children":["$","$L3",null,{}]}],[["$","script","script-0",{"src":"/_next/static/chunks/21rzh-zxtimdt.js","async":true}]],["$","$L4",null,{"children":["$","$2",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"Vc85XfKqI6lI9FCcW022V"}
5:null
