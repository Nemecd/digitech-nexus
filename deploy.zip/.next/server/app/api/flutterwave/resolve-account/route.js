var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/flutterwave/resolve-account/route.js")
R.c("server/chunks/[root-of-the-server]__1dzrlca._.js")
R.c("server/chunks/digitech-nexus_171e1t8._.js")
R.c("server/chunks/04ni_@supabase_supabase-js_dist_index_mjs_04mz8lq._.js")
R.c("server/chunks/[root-of-the-server]__1jr76q4._.js")
R.c("server/chunks/14xo__next-internal_server_app_api_flutterwave_resolve-account_route_actions_0n3efvz.js")
R.m(1239)
module.exports=R.m(1239).exports
