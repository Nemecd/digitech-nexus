1:"$Sreact.fragment"
2:I[31780,["/_next/static/chunks/0vwwrt7l2qbz-.js","/_next/static/chunks/1q-d6daimrahe.js"],"ViewportBoundary"]
3:I[31780,["/_next/static/chunks/0vwwrt7l2qbz-.js","/_next/static/chunks/1q-d6daimrahe.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
5:I[32637,["/_next/static/chunks/0vwwrt7l2qbz-.js","/_next/static/chunks/1q-d6daimrahe.js"],"IconMark"]
0:{"rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"Digitech Nexus"}],["$","meta","1",{"name":"description","content":"Empowering dreams. Building futures."}],["$","link","2",{"rel":"icon","href":"/favicon.ico?favicon.1sf8_xspp4g73.ico","sizes":"48x48","type":"image/x-icon"}],["$","$L5","3",{}]]}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"AVW2tPCFk0fhaLygbcsGg"}
