1:"$Sreact.fragment"
2:"$Sreact.suspense"
3:I[95453,["/_next/static/chunks/0vwwrt7l2qbz-.js","/_next/static/chunks/1q-d6daimrahe.js","/_next/static/chunks/33xk_e35e_r8m.js","/_next/static/chunks/29lv862uucqvj.js"],"default"]
4:I[31780,["/_next/static/chunks/0vwwrt7l2qbz-.js","/_next/static/chunks/1q-d6daimrahe.js"],"OutletBoundary"]
0:{"rsc":["$","$1","c",{"children":[["$","$2",null,{"fallback":["$","div",null,{"className":"min-h-[40vh]"}],"children":["$","$L3",null,{}]}],[["$","script","script-0",{"src":"/_next/static/chunks/33xk_e35e_r8m.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/29lv862uucqvj.js","async":true}]],["$","$L4",null,{"children":["$","$2",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"AVW2tPCFk0fhaLygbcsGg"}
5:null
