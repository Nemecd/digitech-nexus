module.exports=[88367,(a,b,c)=>{}];

//# sourceMappingURL=14xo__next-internal_server_app_%28auth%29_reset-password_page_actions_0wp87jx.js.map