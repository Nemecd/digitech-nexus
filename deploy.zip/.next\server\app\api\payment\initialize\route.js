var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/payment/initialize/route.js")
R.c("server/chunks/[root-of-the-server]__1dc8f03._.js")
R.c("server/chunks/digitech-nexus_171e1t8._.js")
R.c("server/chunks/[root-of-the-server]__1jr76q4._.js")
R.c("server/chunks/04ni_@supabase_supabase-js_dist_index_mjs_04mz8lq._.js")
R.c("server/chunks/14xo__next-internal_server_app_api_payment_initialize_route_actions_0yx4e3n.js")
R.m(41018)
module.exports=R.m(41018).exports
