module.exports=[94672,(a,b,c)=>{}];

//# sourceMappingURL=digitech-nexus__next-internal_server_app_dashboard_page_actions_040qjcq.js.map