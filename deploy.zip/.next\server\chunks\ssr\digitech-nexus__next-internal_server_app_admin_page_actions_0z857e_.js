module.exports=[99742,(a,b,c)=>{}];

//# sourceMappingURL=digitech-nexus__next-internal_server_app_admin_page_actions_0z857e_.js.map