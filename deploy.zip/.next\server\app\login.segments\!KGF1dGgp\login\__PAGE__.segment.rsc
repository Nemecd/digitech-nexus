1:"$Sreact.fragment"
2:"$Sreact.suspense"
3:I[79210,["/_next/static/chunks/3bgr6y9u4sws3.js","/_next/static/chunks/1q-d6daimrahe.js","/_next/static/chunks/0sex9alg06i3s.js","/_next/static/chunks/29lv862uucqvj.js"],"default"]
4:I[31780,["/_next/static/chunks/3bgr6y9u4sws3.js","/_next/static/chunks/1q-d6daimrahe.js"],"OutletBoundary"]
0:{"rsc":["$","$1","c",{"children":[["$","$2",null,{"fallback":["$","div",null,{"className":"min-h-[40vh]"}],"children":["$","$L3",null,{}]}],[["$","script","script-0",{"src":"/_next/static/chunks/0sex9alg06i3s.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/29lv862uucqvj.js","async":true}]],["$","$L4",null,{"children":["$","$2",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"-ql8pK_-NdEVWcBX_GCLj"}
5:null
