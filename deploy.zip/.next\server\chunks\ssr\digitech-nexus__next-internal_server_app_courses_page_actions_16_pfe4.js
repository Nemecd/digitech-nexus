module.exports=[65976,(a,b,c)=>{}];

//# sourceMappingURL=digitech-nexus__next-internal_server_app_courses_page_actions_16_pfe4.js.map